package com.ticketmaster.event.converter;

import com.ticketmaster.event.domain.RestEvent;
import com.ticketmaster.event.entity.EventEntity;

public interface EventConverter {

	RestEvent toRest(EventEntity eventEntity);

	EventEntity toEntity(RestEvent restEvent);

}
