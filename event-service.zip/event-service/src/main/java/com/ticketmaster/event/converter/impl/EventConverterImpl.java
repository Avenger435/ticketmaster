package com.ticketmaster.event.converter.impl;

import org.springframework.stereotype.Component;

import com.ticketmaster.event.converter.EventConverter;
import com.ticketmaster.event.domain.RestEvent;
import com.ticketmaster.event.entity.EventEntity;

@Component
public class EventConverterImpl implements EventConverter {

	@Override
	public RestEvent toRest(EventEntity eventEntity) {
		RestEvent restEvent = new RestEvent();
		restEvent.setId(eventEntity.getId());
		restEvent.setEventName(eventEntity.getEventName());
		restEvent.setEventDate(eventEntity.getEventDate());
		restEvent.setEventType(eventEntity.getEventType());
		restEvent.setEventStatus(eventEntity.getEventStatus());
		restEvent.setOrganiser(eventEntity.getOrganiser());
		return restEvent;
	}

	@Override
	public EventEntity toEntity(RestEvent restEvent) {
		EventEntity eventEntity = new EventEntity();
		eventEntity.setEventName(restEvent.getEventName());
		eventEntity.setEventDate(restEvent.getEventDate());
		eventEntity.setEventType(restEvent.getEventType());
		eventEntity.setEventStatus(restEvent.getEventStatus());
		eventEntity.setOrganiser(restEvent.getOrganiser());
		return eventEntity;

	}

}
