package com.ticketmaster.event;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventServiceApplication {

//	private static final Logger logger = LoggerFactory.getLogger(EventServiceApplication.class);

	public static void main(String[] args) {
//		logger.info("EventService started");
		SpringApplication.run(EventServiceApplication.class, args);
	}

}
