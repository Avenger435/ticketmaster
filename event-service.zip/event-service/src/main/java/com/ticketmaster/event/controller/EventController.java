package com.ticketmaster.event.controller;

import java.util.List;

import org.springframework.http.HttpStatusCode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ticketmaster.event.domain.RestEvent;
import com.ticketmaster.event.service.EventService;

@RestController
@RequestMapping("/api/event")
public class EventController {

	private EventService eventService;

	public EventController(EventService eventService) {
		this.eventService = eventService;
	}

	@GetMapping("/health")
	public String getHealthStatus() {
		return "Health is Ok";
	}

	@GetMapping("/events")
	public ResponseEntity<List<RestEvent>> getAllEvents() {
		List<RestEvent> eventsList = eventService.findAll();
		return new ResponseEntity<>(eventsList, HttpStatusCode.valueOf(200));
	}

	@PostMapping("/post")
	public ResponseEntity<RestEvent> postMethodName(@RequestBody RestEvent restEvent) {
		return new ResponseEntity<>(eventService.save(restEvent), HttpStatusCode.valueOf(201));
	}

}
