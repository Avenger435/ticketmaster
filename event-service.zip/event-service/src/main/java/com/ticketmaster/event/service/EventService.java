package com.ticketmaster.event.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.ticketmaster.event.domain.RestEvent;

@Service
public interface EventService {

	List<RestEvent> findAll();

	RestEvent findEventById(Long id);

	RestEvent save(RestEvent restEvent);

}
