import { registerRoutes } from './auth/auth.routes';
import { Route } from "@angular/router";

export const appRoutes: Route[] =[
  {
    path: 'register',
    //lazy load auth.routes - reading register routes.
    loadChildren: () => import('../app/auth/auth.routes').then(m => m.registerRoutes),
  }
]