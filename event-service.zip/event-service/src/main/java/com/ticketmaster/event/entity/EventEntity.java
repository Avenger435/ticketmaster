package com.ticketmaster.event.entity;

import java.time.LocalDate;

import com.ticketmaster.event.enums.EventStatus;
import com.ticketmaster.event.enums.EventType;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity
@Table(name = "event")
@Data
@EqualsAndHashCode(callSuper = true)
public class EventEntity extends BaseEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	private LocalDate eventDate;
	private String eventName;
	private EventType eventType;
	private EventStatus eventStatus;
	private String organiser;

}
