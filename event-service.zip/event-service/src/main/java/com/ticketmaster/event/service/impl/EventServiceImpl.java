package com.ticketmaster.event.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.ticketmaster.event.converter.impl.EventConverterImpl;
import com.ticketmaster.event.domain.RestEvent;
import com.ticketmaster.event.entity.EventEntity;
import com.ticketmaster.event.repository.EventRepository;
import com.ticketmaster.event.service.EventService;

@Service
public class EventServiceImpl implements EventService {

	private EventRepository eventRepository;
	private EventConverterImpl eventConverterimpl;

	public EventServiceImpl(EventRepository eventRepository, EventConverterImpl eventConverterimpl) {
		this.eventRepository = eventRepository;
		this.eventConverterimpl = eventConverterimpl;
	}

	@Override
	public List<RestEvent> findAll() {
		return eventRepository.findAll().stream().map(e -> eventConverterimpl.toRest(e)).toList();
	}

	@Override
	public RestEvent findEventById(Long id) {
		Optional<EventEntity> eventEntityOptional = eventRepository.findById(id);

		if (eventEntityOptional.isEmpty()) {
			RestEvent restEvent = new RestEvent();
			restEvent.setResponseMsg(String.format("Couldn't find the event with %d", id));
			return restEvent;
		} else {
			return eventConverterimpl.toRest(eventEntityOptional.get());
		}
	}

	@Override
	public RestEvent save(RestEvent restEvent) {
		System.out.println("Service " + restEvent);
		return eventConverterimpl.toRest(eventRepository.saveAndFlush(eventConverterimpl.toEntity(restEvent)));
	}

}
