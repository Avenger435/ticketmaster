package com.ticketmaster.event.domain;

import java.time.LocalDate;

import lombok.Data;


@Data
public class RestBase {

	private LocalDate createdDate;
	private LocalDate updateDate;

}
