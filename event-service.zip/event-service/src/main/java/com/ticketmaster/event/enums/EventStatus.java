package com.ticketmaster.event.enums;

public enum EventStatus {

	LIVE, CONFIRMED, CANCELLED

}
