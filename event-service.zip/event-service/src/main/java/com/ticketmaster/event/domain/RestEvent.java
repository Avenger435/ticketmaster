/**
 * 
 */
package com.ticketmaster.event.domain;

import java.time.LocalDate;

import org.springframework.stereotype.Component;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.ticketmaster.event.entity.BaseEntity;
import com.ticketmaster.event.enums.EventStatus;
import com.ticketmaster.event.enums.EventType;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Component
@Data
@EqualsAndHashCode(callSuper = true)
@JsonInclude(value = Include.NON_NULL)
public class RestEvent extends BaseEntity {

	private Long id;
	private LocalDate eventDate;
	private String eventName;
	private EventType eventType;
	private EventStatus eventStatus;
	private String organiser;
	@JsonIgnore
	private String responseMsg;

}
