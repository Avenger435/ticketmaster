package com.ticketmaster.event.enums;

public enum EventType {
	MOVIES,STREAM, EVENTS,PLAYS,SPORTS,ACTIVITIES
}
