package com.ticketmaster.event.entity;

import java.time.LocalDate;

import lombok.Data;

@Data
public class BaseEntity {

	private LocalDate createdDate;
	private LocalDate updateDate;

}
